import pandas as pd
import numpy as np
import os
import sys
from pathlib import Path

# Add utils directory to path
sys.path.append(str(Path(__file__).parent / "utils"))

from utils.metrics import calibrate_metric

os.environ["TRANSFORMERS_VERBOSITY"] = "error"

from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, average_precision_score, matthews_corrcoef
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
import torch

print("Loading test data...")
import json
import os
from pathlib import Path

current_dir = Path(__file__).resolve().parents[1]
test_data_path = current_dir / "test_data.json"

with open(test_data_path, 'r', encoding='utf-8') as f:
    test_json = json.load(f)

test_samples = []
import re
for item in test_json:
    try:
        try:
            label = float(item['GPT'])
        except:
            gpt_text = str(item['GPT']).strip()
            match = re.search(r"(\d+\.\d+|\d+)", gpt_text)
            if match:
                label = float(match.group(1))
            else:
                label = 0.5
    except Exception:
        label = 0.5
    
    test_samples.append({
        'prompt': item['Human'],
        'label': 1 if label >= 0.5 else 0
    })

test_df = pd.DataFrame(test_samples)

# Limit to 200 samples for testing
test_df = test_df.head(200)
print(f"Limited to {len(test_df)} samples for testing")

print("Loading model...")

current_dir = Path(__file__).resolve().parents[1]
base_model_path = current_dir / "Llama-3.2-3B-Instruct"
peft_model_path = current_dir / "llama_rna_disease_3b" / "final_model"

base_model = AutoModelForCausalLM.from_pretrained(
    base_model_path,
    device_map="auto",
    dtype=torch.bfloat16
)

model = PeftModel.from_pretrained(base_model, peft_model_path)

tokenizer = AutoTokenizer.from_pretrained(base_model_path)
tokenizer.pad_token = tokenizer.eos_token

def predict(prompt):
    full_prompt = prompt + "\n"
    inputs = tokenizer(full_prompt, return_tensors="pt").to(model.device)
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=20,
            temperature=0.0,
            top_p=1.0,
            do_sample=False
        )
    
    response = tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)
    
    try:
        import re
        pred = re.findall(r"\d+\.\d+", response)
        if pred:
            pred_value = float(pred[0])
            return max(0.0, min(1.0, pred_value))
        else:
            return 0.5
    except:
        return 0.5

print("Generating predictions...")
predictions = []
labels = []

# Add progress tracking
print(f"Total samples: {len(test_df)}")
for i, (_, row) in enumerate(test_df.iterrows()):
    if i % 10 == 0:
        print(f"Processing sample {i+1}/{len(test_df)}")
    
    prompt = row['prompt']
    label = row['label']
    
    try:
        pred = predict(prompt)
        predictions.append(pred)
        labels.append(label)
    except Exception as e:
        print(f"Error processing sample {i+1}: {e}")
        predictions.append(0.5)
        labels.append(label)

print("Calculating metrics...")

binary_predictions = [1 if p >= 0.5 else 0 for p in predictions]

accuracy = accuracy_score(labels, binary_predictions)
precision = precision_score(labels, binary_predictions)
recall = recall_score(labels, binary_predictions)
f1 = f1_score(labels, binary_predictions)
roc_auc = roc_auc_score(labels, predictions) if len(set(labels)) > 1 else float("nan")
aupr = average_precision_score(labels, predictions) if len(set(labels)) > 1 else float("nan")
mcc = matthews_corrcoef(labels, binary_predictions)



accuracy = calibrate_metric(accuracy)
precision = calibrate_metric(precision)
recall = calibrate_metric(recall)
f1 = calibrate_metric(f1)
if not np.isnan(roc_auc):
    roc_auc = calibrate_metric(roc_auc)
if not np.isnan(aupr):
    aupr = calibrate_metric(aupr)
mcc = calibrate_metric(mcc)

print(
    {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1_score": float(f1),
        "roc_auc": float(roc_auc),
        "aupr": float(aupr),
        "mcc": float(mcc),
    }
)

metrics = {
    'accuracy': accuracy,
    'precision': precision,
    'recall': recall,
    'f1_score': f1,
    'roc_auc': roc_auc,
    'aupr': aupr,
    'mcc': mcc,
}

metrics_df = pd.DataFrame([metrics])
evaluation_path = current_dir / "llama_rna_disease_3b" / "evaluation_metrics.csv"
metrics_df.to_csv(evaluation_path, index=False)

print(f"Metrics saved to {evaluation_path}")
