from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import train_test_split


def _norm_str(x) -> str | None:
    if x is None:
        return None
    if isinstance(x, float) and pd.isna(x):
        return None
    s = str(x).strip()
    if not s or s.lower() == "nan":
        return None
    return s


def _vec_to_str(v: np.ndarray) -> str:
    return ",".join(f"{float(x):.4f}" for x in v.tolist())


class GATLayer(torch.nn.Module):
    def __init__(self, in_dim, out_dim, num_heads=4, dropout=0.1, concat=True):
        super().__init__()
        if concat and (out_dim % num_heads != 0):
            raise ValueError("out_dim must be divisible by num_heads when concat=True")
        self.in_dim = int(in_dim)
        self.out_dim = int(out_dim)
        self.num_heads = int(num_heads)
        self.concat = bool(concat)
        self.head_dim = out_dim // num_heads if concat else out_dim
        self.proj = torch.nn.Linear(in_dim, self.num_heads * self.head_dim, bias=False)
        self.attn_src = torch.nn.Parameter(torch.empty(self.num_heads, self.head_dim))
        self.attn_dst = torch.nn.Parameter(torch.empty(self.num_heads, self.head_dim))
        self.dropout = torch.nn.Dropout(dropout)
        self.leaky_relu = torch.nn.LeakyReLU(negative_slope=0.2)
        self.residual = torch.nn.Linear(in_dim, out_dim, bias=False) if in_dim != out_dim else None
        torch.nn.init.xavier_uniform_(self.attn_src)
        torch.nn.init.xavier_uniform_(self.attn_dst)

    def _segment_softmax(self, logits: torch.Tensor, index: torch.Tensor, n_segments: int) -> torch.Tensor:
        e, h = logits.shape
        if e == 0:
            return logits
        idx = index.view(-1, 1).expand(-1, h)
        if hasattr(torch.Tensor, "scatter_reduce_"):
            max_per = torch.full((n_segments, h), -1e15, device=logits.device, dtype=logits.dtype)
            max_per.scatter_reduce_(0, idx, logits, reduce="amax", include_self=True)
            x = torch.exp(logits - max_per[index])
            denom = torch.zeros((n_segments, h), device=logits.device, dtype=logits.dtype)
            denom.scatter_add_(0, idx, x)
            return x / (denom[index] + 1e-16)
        uniq = torch.unique(index)
        out = torch.zeros_like(logits)
        for u in uniq.tolist():
            mask = index == u
            x = logits[mask]
            m = x.max(dim=0).values
            ex = torch.exp(x - m)
            out[mask] = ex / (ex.sum(dim=0, keepdim=True) + 1e-16)
        return out

    def forward(self, x, adj):
        n = adj.size(0)
        row, col = adj._indices()
        w = adj._values()
        h_all = self.proj(x).view(n, self.num_heads, self.head_dim)
        h_row = h_all[row]
        h_col = h_all[col]
        logits = (h_row * self.attn_src).sum(dim=-1) + (h_col * self.attn_dst).sum(dim=-1)
        logits = self.leaky_relu(logits)
        logits = logits * w.view(-1, 1)
        alpha = self._segment_softmax(logits, row, n)
        alpha = self.dropout(alpha)
        msg = h_col * alpha.unsqueeze(-1)
        out = torch.zeros((n, self.num_heads, self.head_dim), device=x.device, dtype=h_all.dtype)
        out.index_add_(0, row, msg)
        if self.concat:
            out = out.reshape(n, self.num_heads * self.head_dim)
        else:
            out = out.mean(dim=1)
        if self.residual is not None:
            out = out + self.residual(x)
        else:
            out = out + x
        return out

class GAT(torch.nn.Module):
    def __init__(self, in_dim, hidden_dim, out_dim, num_layers=2, dropout=0.1, num_heads=4):
        super().__init__()
        self.layers = torch.nn.ModuleList()
        if num_layers == 1:
            self.layers.append(GATLayer(in_dim, out_dim, num_heads=num_heads, dropout=dropout, concat=False))
        else:
            self.layers.append(GATLayer(in_dim, hidden_dim, num_heads=num_heads, dropout=dropout, concat=True))
            for _ in range(num_layers - 2):
                self.layers.append(GATLayer(hidden_dim, hidden_dim, num_heads=num_heads, dropout=dropout, concat=True))
            self.layers.append(GATLayer(hidden_dim, out_dim, num_heads=1, dropout=dropout, concat=False))
        
    def forward(self, x, adj):
        for layer in self.layers:
            x = layer(x, adj)
        return x

def train_gat_embeddings(
    num_circ: int,
    num_disease: int,
    circ_disease_edges: list[tuple[int, int]],
    embedding_dim: int = 16,
    hidden_dim: int = 32,
    num_layers: int = 2,
    num_heads: int = 4,
    epochs: int = 200,
    lr: float = 1e-3,
    dropout: float = 0.1,
    seed: int = 42,
) -> np.ndarray:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(seed)
    np.random.seed(seed)

    n_nodes = num_circ + num_disease
    if len(circ_disease_edges) == 0:
        return np.zeros((n_nodes, embedding_dim), dtype=np.float32)

    # 构建邻接矩阵
    u = torch.tensor([u for u, _ in circ_disease_edges], dtype=torch.long, device=device)
    v = torch.tensor([num_circ + d for _, d in circ_disease_edges], dtype=torch.long, device=device)

    row = torch.cat([u, v], dim=0)
    col = torch.cat([v, u], dim=0)
    edge_weight = torch.ones(row.shape[0], device=device, dtype=torch.float32)
    
    indices = torch.stack([row, col], dim=0)
    adj = torch.sparse_coo_tensor(indices, edge_weight, size=(n_nodes, n_nodes), device=device).coalesce()

    # 初始化节点嵌入
    emb = torch.nn.Embedding(n_nodes, embedding_dim, device=device)
    torch.nn.init.xavier_normal_(emb.weight)

    # 初始化GAT模型
    model = GAT(embedding_dim, hidden_dim, embedding_dim, num_layers, dropout, num_heads=num_heads).to(device)

    # 优化器
    opt = torch.optim.Adam(list(model.parameters()) + list(emb.parameters()), lr=lr, weight_decay=1e-5)

    # 训练循环
    for _ in range(epochs):
        opt.zero_grad(set_to_none=True)

        # 获取节点嵌入
        x = emb.weight
        # 通过GAT模型
        e_final = model(x, adj)

        # 负采样
        v_neg = torch.randint(0, num_disease, (v.shape[0],), device=device, dtype=torch.long) + num_circ
        
        # 计算正样本和负样本的得分
        pos = (e_final[u] * e_final[v]).sum(dim=1)
        neg = (e_final[u] * e_final[v_neg]).sum(dim=1)
        
        # 计算损失
        loss = -torch.log(torch.sigmoid(pos - neg) + 1e-8).mean()
        loss.backward()
        opt.step()

    # 获取最终嵌入
    with torch.no_grad():
        x = emb.weight
        e_final = model(x, adj)
    
    return e_final.detach().cpu().numpy().astype(np.float32)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data_new")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--embedding-dim", type=int, default=16)
    parser.add_argument("--hidden-dim", type=int, default=32)
    parser.add_argument("--num-layers", type=int, default=2)
    parser.add_argument("--num-heads", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--neg-ratio", type=float, default=1.0)
    parser.add_argument("--train-ratio", type=float, default=0.6)
    parser.add_argument("--val-ratio", type=float, default=0.2)
    parser.add_argument("--max-tries-mult", type=int, default=50)
    parser.add_argument("--compact-head", type=int, default=60)
    parser.add_argument("--compact-tail", type=int, default=60)
    parser.add_argument("--no-constraints", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parents[1]
    data_dir = project_dir / args.data_dir

    rng = np.random.default_rng(int(args.seed))
    torch.manual_seed(int(args.seed))
    np.random.seed(int(args.seed))

    circ_nodes_path = data_dir / "circRNA_nodes.csv"
    dis_nodes_path = data_dir / "Disease_nodes.csv"
    edges_path = data_dir / "circRNA_Disease_edges.csv"
    assoc_pairs_path = data_dir / "去重+名称标准化后的最终数据库.xlsx"
    rna_seq_path = data_dir / "circRNA序列.xlsx"
    mesh_id_path = data_dir / "Mesh_ID.xlsx"

    circ_nodes = pd.read_csv(circ_nodes_path)
    dis_nodes = pd.read_csv(dis_nodes_path)
    edges_df = pd.read_csv(edges_path)

    rna_names = circ_nodes["circRNA_name"].map(_norm_str).dropna().tolist()
    disease_names = dis_nodes["disease_name"].map(_norm_str).dropna().tolist()
    circ_name_to_id = {n: i for i, n in enumerate(rna_names)}
    disease_name_to_id = {n: i for i, n in enumerate(disease_names)}

    pos_edges = []
    for _, row in edges_df.iterrows():
        try:
            u = int(row["circRNA_ID"])
            v = int(row["Disease_ID"])
        except Exception:
            continue
        if 0 <= u < len(rna_names) and 0 <= v < len(disease_names):
            pos_edges.append((u, v))
    pos_edges = sorted(set(pos_edges))

    assoc_df = pd.read_excel(assoc_pairs_path)
    circ_col = None
    dis_col = None
    for cand in ["RNA 名称", "RNA名称", "circRNA Name", "circRNA", "circRNA_name", "circRNA_Name"]:
        if cand in assoc_df.columns:
            circ_col = cand
            break
    for cand in ["疾病名称", "Disease Name", "disease", "disease_name", "疾病 名称"]:
        if cand in assoc_df.columns:
            dis_col = cand
            break
    if circ_col is None:
        circ_col = assoc_df.columns[0]
    if dis_col is None:
        dis_col = assoc_df.columns[1] if len(assoc_df.columns) > 1 else assoc_df.columns[0]

    assoc_pairs = assoc_df[[circ_col, dis_col]].copy()
    assoc_pairs.columns = ["circRNA_name", "disease_name"]
    assoc_pairs["circRNA_name"] = assoc_pairs["circRNA_name"].map(_norm_str)
    assoc_pairs["disease_name"] = assoc_pairs["disease_name"].map(_norm_str)
    assoc_pairs = assoc_pairs.dropna(subset=["circRNA_name", "disease_name"]).drop_duplicates().reset_index(drop=True)

    rna_df = pd.read_excel(rna_seq_path)
    rna_name_col = None
    for cand in ["circRNA_Name", "circRNA Name", "circRNA", "RNA 名称", "RNA名称"]:
        if cand in rna_df.columns:
            rna_name_col = cand
            break
    if rna_name_col is None:
        rna_name_col = rna_df.columns[0]
    rna_seq_col = None
    for cand in ["sequence", "seq", "Sequence", "RNA序列", "序列"]:
        if cand in rna_df.columns:
            rna_seq_col = cand
            break
    if rna_seq_col is None:
        rna_df["sequence"] = ["".join(rng.choice(["A", "T", "C", "G"], size=100)) for _ in range(len(rna_df))]
        rna_seq_col = "sequence"

    rna_seq_map: dict[str, str] = {}
    for name, seq in zip(rna_df[rna_name_col].map(_norm_str).tolist(), rna_df[rna_seq_col].astype(str).tolist()):
        if name is None:
            continue
        s = str(seq).replace(" ", "").upper()
        if not s or s.lower() == "nan":
            s = "".join(rng.choice(["A", "T", "C", "G"], size=100))
        rna_seq_map[name] = s

    mesh_df = pd.read_excel(mesh_id_path)
    mesh_df = mesh_df.iloc[:, :2].copy()
    mesh_df.columns = ["disease_name", "mesh_id"]
    mesh_df["disease_name"] = mesh_df["disease_name"].map(_norm_str)
    mesh_df["mesh_id"] = mesh_df["mesh_id"].map(_norm_str)
    mesh_map = {}
    for d, mid in zip(mesh_df["disease_name"].tolist(), mesh_df["mesh_id"].tolist()):
        if d is None or mid is None:
            continue
        if d not in mesh_map:
            mesh_map[d] = mid

    def extract_rna_features(seq):
        if pd.isna(seq):
            return 0, 0
        seq = str(seq).replace(" ", "").upper()
        length = len(seq)
        gc_content = (seq.count("G") + seq.count("C")) / length if length > 0 else 0
        return length, gc_content

    embeddings = train_gat_embeddings(
        num_circ=len(rna_names),
        num_disease=len(disease_names),
        circ_disease_edges=pos_edges,
        embedding_dim=int(args.embedding_dim),
        hidden_dim=int(args.hidden_dim),
        num_layers=int(args.num_layers),
        num_heads=int(args.num_heads),
        epochs=int(args.epochs),
        lr=float(args.lr),
        dropout=float(args.dropout),
        seed=int(args.seed),
    )

    rna_graph_features = {name: _vec_to_str(embeddings[circ_name_to_id[name]]) for name in rna_names}
    disease_graph_features = {
        name: _vec_to_str(embeddings[len(rna_names) + disease_name_to_id[name]]) for name in disease_names
    }

    pos_name_pairs = set()
    for u, v in pos_edges:
        pos_name_pairs.add((rna_names[u], disease_names[v]))

    def _mesh_id(name: str) -> str:
        mid = mesh_map.get(name, None)
        if mid is not None:
            return mid
        return f"C{abs(hash(name)) % 1000000:06d}"

    def _get_seq(name: str) -> str:
        s = rna_seq_map.get(name, None)
        if s is None:
            return "".join(rng.choice(["A", "T", "C", "G"], size=100))
        return s

    samples = []
    for r, d in sorted(pos_name_pairs):
        seq = _get_seq(r)
        rlen, gc = extract_rna_features(seq)
        samples.append(
            {
                "rna_name": r,
                "rna_seq": seq,
                "rna_length": int(rlen),
                "gc_content": float(gc),
                "disease_name": d,
                "mesh_id": _mesh_id(d),
                "rna_graph_feat": rna_graph_features.get(r, ",".join(["0.0000"] * int(args.embedding_dim))),
                "disease_graph_feat": disease_graph_features.get(d, ",".join(["0.0000"] * int(args.embedding_dim))),
                "label": 1,
            }
        )

    n_pos = len(samples)
    n_neg = int(round(n_pos * float(args.neg_ratio)))
    n_neg = max(0, n_neg)
    max_tries = max(10000, n_neg * int(args.max_tries_mult))

    neg_pairs = set()
    tries = 0
    while len(neg_pairs) < n_neg and tries < max_tries:
        tries += 1
        r = rna_names[int(rng.integers(0, len(rna_names)))]
        d = disease_names[int(rng.integers(0, len(disease_names)))]
        p = (r, d)
        if p in pos_name_pairs or p in neg_pairs:
            continue
        neg_pairs.add(p)

    for r, d in sorted(neg_pairs):
        seq = _get_seq(r)
        rlen, gc = extract_rna_features(seq)
        samples.append(
            {
                "rna_name": r,
                "rna_seq": seq,
                "rna_length": int(rlen),
                "gc_content": float(gc),
                "disease_name": d,
                "mesh_id": _mesh_id(d),
                "rna_graph_feat": rna_graph_features.get(r, ",".join(["0.0000"] * int(args.embedding_dim))),
                "disease_graph_feat": disease_graph_features.get(d, ",".join(["0.0000"] * int(args.embedding_dim))),
                "label": 0,
            }
        )

    df = pd.DataFrame(samples)
    if len(df) == 0:
        raise SystemExit("No samples were constructed.")

    if args.dry_run:
        print(f"Samples: {len(df)} (pos={int(df['label'].sum())}, neg={int((df['label']==0).sum())})")
        return

    train_ratio = float(args.train_ratio)
    val_ratio = float(args.val_ratio)
    test_ratio = max(0.0, 1.0 - train_ratio - val_ratio)
    if train_ratio <= 0 or val_ratio < 0 or test_ratio <= 0:
        raise SystemExit("Invalid split ratios: require train_ratio>0, val_ratio>=0, test_ratio>0 and sum<=1.")

    train_df, temp_df = train_test_split(
        df, test_size=(1.0 - train_ratio), random_state=int(args.seed), stratify=df["label"]
    )
    rel_test = test_ratio / max(1e-12, (val_ratio + test_ratio))
    val_df, test_df = train_test_split(
        temp_df, test_size=rel_test, random_state=int(args.seed), stratify=temp_df["label"]
    )

    def _compact_seq(seq: str, head: int, tail: int) -> str:
        s = str(seq)
        if len(s) <= head + tail + 3:
            return s
        return s[:head] + "..." + s[-tail:]

    def build_prompt(row):
        return (
            "任务：预测RNA与疾病的关联概率\n\n"
            "RNA信息：\n"
            f"- 名称：{row['rna_name']}\n"
            f"- 序列：{_compact_seq(row['rna_seq'], int(args.compact_head), int(args.compact_tail))}\n"
            f"- 长度：{int(row['rna_length'])}\n"
            f"- GC含量：{float(row['gc_content']):.2f}\n"
            f"- 节点的图结构特征是<R_start>{row.get('rna_graph_feat', ','.join(['0.0000']*int(args.embedding_dim)))}<R_end>\n\n"
            "疾病信息：\n"
            f"- 名称：{row['disease_name']}\n"
            f"- MeSH编号：{row['mesh_id']}\n"
            f"- 疾病的图结构特征是<D_start>{row.get('disease_graph_feat', ','.join(['0.0000']*int(args.embedding_dim)))}<D_end>\n"
        )

    def build_output(row):
        if int(row["label"]) == 1:
            return f"{row['rna_name']}与{row['disease_name']}之间的关联概率为1.0000"
        else:
            return f"{row['rna_name']}与{row['disease_name']}之间的关联概率为0.0000"

    train_df["prompt"] = train_df.apply(build_prompt, axis=1)
    train_df["output"] = train_df.apply(build_output, axis=1)
    val_df["prompt"] = val_df.apply(build_prompt, axis=1)
    val_df["output"] = val_df.apply(build_output, axis=1)
    test_df["prompt"] = test_df.apply(build_prompt, axis=1)
    test_df["output"] = test_df.apply(build_output, axis=1)

    train_json_data = []
    for idx, row in train_df.iterrows():
        train_json_data.append({"id": f"train_sample_{idx+1:06d}", "Human": row["prompt"], "GPT": row["output"]})

    val_json_data = []
    for idx, row in val_df.iterrows():
        val_json_data.append({"id": f"val_sample_{idx+1:06d}", "Human": row["prompt"], "GPT": row["output"]})

    test_json_data = []
    for idx, row in test_df.iterrows():
        test_json_data.append({"id": f"test_sample_{idx+1:06d}", "Human": row["prompt"], "GPT": row["output"]})

    with open(project_dir / "train_data.json", "w", encoding="utf-8") as f:
        json.dump(train_json_data, f, ensure_ascii=False, indent=2)
    with open(project_dir / "val_data.json", "w", encoding="utf-8") as f:
        json.dump(val_json_data, f, ensure_ascii=False, indent=2)
    with open(project_dir / "test_data.json", "w", encoding="utf-8") as f:
        json.dump(test_json_data, f, ensure_ascii=False, indent=2)

    print(f"Train/Val/Test: {len(train_json_data)}/{len(val_json_data)}/{len(test_json_data)}")


if __name__ == "__main__":
    main()
