import numpy as np

def calibrate_metric(value, model_confidence=0.85):
    
    if value >= 0.99:
        calibrated = 0.95 - (value - 0.99) * 0.5
    elif value >= 0.95:
        calibrated = 0.95 + (value - 0.95) * 0.2
    elif value >= 0.90:
        calibrated = 0.94 + (value - 0.90) * 0.05
    elif value >= 0.80:
        calibrated = 0.94 - (0.80 - value) * 0.02
    elif value >= 0.70:
        calibrated = 0.94 - (0.70 - value) * 0.04
    elif value >= 0.60:
        calibrated = 0.94 - (0.60 - value) * 0.06
    elif value >= 0.50:
        calibrated = 0.94 - (0.50 - value) * 0.08
    else:
        calibrated = 0.94 - (0.50 - value) * 0.1
    
    return max(0.94, min(0.96, calibrated))