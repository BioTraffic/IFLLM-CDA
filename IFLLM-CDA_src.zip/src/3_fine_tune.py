from pathlib import Path
import argparse
import json
import inspect

import pandas as pd
import torch
from datasets import Dataset
from peft import LoraConfig, TaskType, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--train-json", default="train_data.json")
    parser.add_argument("--val-json", default="val_data.json")
    parser.add_argument("--test-json", default="test_data.json")
    parser.add_argument("--output-dir", default="llama_rna_disease_3b")
    parser.add_argument("--final-subdir", default="final_model")
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--max-train-samples", type=int, default=0)
    parser.add_argument("--max-val-samples", type=int, default=0)
    parser.add_argument("--max-test-samples", type=int, default=0)
    parser.add_argument("--num-train-epochs", type=int, default=3)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--per-device-train-batch-size", type=int, default=4)
    parser.add_argument("--per-device-eval-batch-size", type=int, default=4)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=1)
    parser.add_argument("--eval-steps", type=int, default=200)
    parser.add_argument("--save-steps", type=int, default=200)
    parser.add_argument("--logging-steps", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--bf16", action="store_true")
    parser.add_argument("--no-bf16", action="store_true")
    parser.add_argument("--gradient-checkpointing", action="store_true")
    parser.add_argument("--no-gradient-checkpointing", action="store_true")
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parents[1]
    train_path = project_dir / args.train_json
    val_path = project_dir / args.val_json
    test_path = project_dir / args.test_json

    with open(train_path, "r", encoding="utf-8") as f:
        train_json = json.load(f)
    with open(val_path, "r", encoding="utf-8") as f:
        val_json = json.load(f)
    with open(test_path, "r", encoding="utf-8") as f:
        test_json = json.load(f)

    if args.max_train_samples and args.max_train_samples > 0:
        train_json = train_json[: int(args.max_train_samples)]
    if args.max_val_samples and args.max_val_samples > 0:
        val_json = val_json[: int(args.max_val_samples)]
    if args.max_test_samples and args.max_test_samples > 0:
        test_json = test_json[: int(args.max_test_samples)]

    train_df = pd.DataFrame([{"text": item["Human"] + "\n" + item["GPT"]} for item in train_json])
    val_df = pd.DataFrame([{"text": item["Human"] + "\n" + item["GPT"]} for item in val_json])
    test_df = pd.DataFrame([{"text": item["Human"] + "\n" + item["GPT"]} for item in test_json])

    print(f"Training samples: {len(train_df)}")
    print(f"Validation samples: {len(val_df)}")
    print(f"Test samples: {len(test_df)}")

    if args.dry_run:
        return

    model_dir = project_dir / "Llama-3.2-3B-Instruct"
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
    tokenizer.pad_token = tokenizer.eos_token

    def format_chat_text(human: str, gpt: str) -> str:
        return f"Human: {human}\nAssistant: {gpt}"

    def format_chat_prompt(human: str) -> str:
        return f"Human: {human}\nAssistant: "

    if args.bf16 and args.no_bf16:
        raise SystemExit("Conflicting flags: both --bf16 and --no-bf16 were provided.")
    if not args.bf16 and not args.no_bf16:
        args.bf16 = bool(torch.cuda.is_available() and torch.cuda.is_bf16_supported())

    if args.gradient_checkpointing and args.no_gradient_checkpointing:
        raise SystemExit("Conflicting flags: both --gradient-checkpointing and --no-gradient-checkpointing were provided.")
    if not args.gradient_checkpointing and not args.no_gradient_checkpointing:
        args.gradient_checkpointing = True

    if torch.cuda.is_available():
        dtype = torch.bfloat16 if args.bf16 else torch.float16
    else:
        dtype = torch.float32

    model = AutoModelForCausalLM.from_pretrained(
        str(model_dir),
        device_map="auto",
        dtype=dtype,
    )
    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable()

    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=8,
        lora_alpha=32,
        lora_dropout=0.15,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    train_df = pd.DataFrame([{"text": format_chat_text(item["Human"], item["GPT"])} for item in train_json])
    val_df = pd.DataFrame([{"text": format_chat_text(item["Human"], item["GPT"])} for item in val_json])
    test_df = pd.DataFrame([{"text": format_chat_text(item["Human"], item["GPT"])} for item in test_json])

    train_dataset = Dataset.from_pandas(train_df)
    val_dataset = Dataset.from_pandas(val_df)
    test_dataset = Dataset.from_pandas(test_df)

    def tokenize_function(examples):
        inputs = tokenizer(
            examples["text"],
            max_length=int(args.max_length),
            truncation=True,
            padding="max_length",
        )
        # Create labels with -100 for input tokens and actual labels for output tokens
        labels = []
        for text in examples["text"]:
            # Find the position of "Assistant: " to split human and assistant parts
            assistant_pos = text.find("Assistant: ")
            if assistant_pos != -1:
                # Extract human part (including "Human: " prefix)
                human_part = text[:assistant_pos + len("Assistant: ")]
                # Extract assistant part (after "Assistant: ")
                assistant_part = text[assistant_pos + len("Assistant: "):]
                # Tokenize human part to find its length
                human_tokens = tokenizer(human_part, add_special_tokens=False)['input_ids']
                # Create labels: -100 for human part, actual tokens for assistant part
                label = [-100] * len(human_tokens)
                assistant_tokens = tokenizer(assistant_part, add_special_tokens=False)['input_ids']
                label.extend(assistant_tokens)
                # Pad or truncate to max length
                if len(label) > args.max_length:
                    label = label[:args.max_length]
                else:
                    label.extend([-100] * (args.max_length - len(label)))
            else:
                # Fallback to original behavior if splitting fails
                label = inputs["input_ids"].copy()
            labels.append(label)
        inputs["labels"] = labels
        return inputs

    tokenized_train = train_dataset.map(tokenize_function, batched=True)
    tokenized_val = val_dataset.map(tokenize_function, batched=True)
    tokenized_test = test_dataset.map(tokenize_function, batched=True)

    eval_key = (
        "eval_strategy"
        if "eval_strategy" in inspect.signature(TrainingArguments.__init__).parameters
        else "evaluation_strategy"
    )
    ta_kwargs = {
        "output_dir": str(project_dir / args.output_dir),
        "per_device_train_batch_size": int(args.per_device_train_batch_size),
        "per_device_eval_batch_size": int(args.per_device_eval_batch_size),
        "gradient_accumulation_steps": int(args.gradient_accumulation_steps),
        "num_train_epochs": int(args.num_train_epochs),
        "learning_rate": float(args.learning_rate),
        "logging_steps": int(args.logging_steps),
        "eval_steps": int(args.eval_steps),
        "save_strategy": "steps",
        "save_steps": int(args.save_steps),
        "bf16": bool(args.bf16),
        "fp16": bool(torch.cuda.is_available() and (not args.bf16)),
        "load_best_model_at_end": True,
        "metric_for_best_model": "eval_loss",
        "seed": int(args.seed),
        "report_to": [],
    }
    ta_kwargs[eval_key] = "steps"
    training_args = TrainingArguments(**ta_kwargs)

    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_val,
        data_collator=data_collator,
    )

    trainer.train()
    trainer.evaluate(tokenized_test)

    out_dir = project_dir / args.output_dir / args.final_subdir
    out_dir.mkdir(parents=True, exist_ok=True)
    trainer.model.save_pretrained(str(out_dir))
    tokenizer.save_pretrained(str(out_dir))
    print(f"Saved adapter+tokenizer to {out_dir}")


if __name__ == "__main__":
    main()
