from pathlib import Path
import argparse
import json
import re
import os
import warnings

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

# 禁用所有警告信息
os.environ.setdefault("TRANSFORMERS_VERBOSITY", "error")
warnings.filterwarnings("ignore")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-json", default="test_data.json")
    parser.add_argument("--max-samples", type=int, default=5)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parents[1]
    input_path = project_dir / args.input_json

    with open(input_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    if args.dry_run:
        return

    model_dir = project_dir / "Llama-3.2-3B-Instruct"
    peft_model_dir = project_dir / "llama_rna_disease_3b" / "final_model"

    base_model = AutoModelForCausalLM.from_pretrained(
        str(model_dir),
        device_map="auto",
        dtype=torch.bfloat16,
    )
    model = PeftModel.from_pretrained(base_model, str(peft_model_dir))

    tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
    tokenizer.pad_token = tokenizer.eos_token

    def _clamp01(v: float) -> float:
        return max(0.0, min(1.0, v))

    def extract_names(input_text):
        # 从输入文本中提取RNA名称和疾病名称
        rna_name = ""
        disease_name = ""
        
        # 提取RNA名称
        rna_match = re.search(r"- 名称：([^\n]+)", input_text)
        if rna_match:
            rna_name = rna_match.group(1)
        
        # 提取疾病名称
        disease_match = re.search(r"疾病信息：\s*- 名称：([^\n]+)", input_text)
        if disease_match:
            disease_name = disease_match.group(1)
        
        return rna_name, disease_name

    def score_logprob(prompt_text: str) -> tuple[float, str]:
        inputs = tokenizer(prompt_text + "\n", return_tensors="pt").to(model.device)
        input_ids = inputs["input_ids"]
        ctx_len = input_ids.shape[1]

        cand0_strs = ["0", "0.0"]
        cand1_strs = ["1", "1.0"]
        cand0_list = [
            tokenizer(s, add_special_tokens=False, return_tensors="pt").to(model.device)["input_ids"] for s in cand0_strs
        ]
        cand1_list = [
            tokenizer(s, add_special_tokens=False, return_tensors="pt").to(model.device)["input_ids"] for s in cand1_strs
        ]

        with torch.inference_mode():
            out = model(input_ids, use_cache=True)
        past = out.past_key_values
        next_logits = out.logits[:, -1, :]
        next_log_probs = torch.log_softmax(next_logits, dim=-1)

        def _score_seq(seq_ids: torch.Tensor) -> torch.Tensor:
            seq = seq_ids[0].tolist()
            lp = next_log_probs[0, seq[0]]
            past_i = past
            for j in range(len(seq) - 1):
                tok = seq[j]
                tok_t = torch.tensor([[tok]], device=model.device, dtype=torch.long)
                with torch.inference_mode():
                    out_i = model(tok_t, past_key_values=past_i, use_cache=True)
                past_i = out_i.past_key_values
                logits_i = out_i.logits[:, -1, :]
                log_probs_i = torch.log_softmax(logits_i, dim=-1)
                lp = lp + log_probs_i[0, seq[j + 1]]
            return lp

        lp0 = torch.logsumexp(torch.stack([_score_seq(c) for c in cand0_list]), dim=0)
        lp1 = torch.logsumexp(torch.stack([_score_seq(c) for c in cand1_list]), dim=0)
        p = float(torch.sigmoid(lp1 - lp0).item())
        # 对于logprob模式，生成一个简单的输出表示
        output = f"{p:.4f}"
        return _clamp01(p), output

    for item in items[: max(0, args.max_samples)]:
        input_text = item["Human"]
        # 去掉要求部分
        if "要求：" in input_text:
            input_text = input_text.split("要求：")[0].strip()
        rna_name, disease_name = extract_names(input_text)
        pred, prob = score_logprob(input_text)
        if rna_name and disease_name:
            output = f"{rna_name}与{disease_name}之间的关联概率为{prob}"
        else:
            output = prob
        print(f"Input: {input_text}")
        print(f"Output: {output}")
        print()


if __name__ == "__main__":
    main()
