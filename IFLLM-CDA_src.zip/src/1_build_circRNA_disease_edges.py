from __future__ import annotations

from dataclasses import dataclass
import argparse
from pathlib import Path
from typing import Iterable

import pandas as pd


@dataclass(frozen=True)
class NodeMappings:
    circRNA_name_to_id: dict[str, int]
    disease_name_to_id: dict[str, int]


def _norm_str(x) -> str | None:
    if x is None:
        return None
    if isinstance(x, float) and pd.isna(x):
        return None
    s = str(x).strip()
    if not s or s.lower() == "nan":
        return None
    return s


def _unique_strs(xs: Iterable) -> list[str]:
    out = []
    seen = set()
    for x in xs:
        s = _norm_str(x)
        if s is None:
            continue
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def build_node_mappings(
    data_dir: Path,
    disease_file: str = "275GS_DMS.xlsx",
    association_matrix_file: str = "associationMatrix.xlsx",
    circRNA_similarity_file: str = "Integrated_sqe_fun_circRNA_similarity_2738.xlsx",
    validate_consistency: bool = False,
) -> NodeMappings:
    disease_path = data_dir / disease_file
    assoc_path = data_dir / association_matrix_file
    circ_sim_path = data_dir / circRNA_similarity_file

    assoc_header = pd.read_excel(assoc_path, sheet_name=0, nrows=0).columns.tolist()
    disease_order = _unique_strs([_norm_str(c) for c in assoc_header[1:]])

    assoc_first_col = pd.read_excel(assoc_path, sheet_name=0, usecols=[0], header=0).iloc[:, 0]
    circ_order = _unique_strs(assoc_first_col.tolist())

    if validate_consistency:
        dis_header = pd.read_excel(disease_path, sheet_name=0, nrows=0).columns.tolist()
        dis_header = [_norm_str(c) for c in dis_header]
        dis_header = [c for c in dis_header if c is not None]
        if len(dis_header) >= 2 and dis_header[1:] != disease_order:
            raise ValueError("275GS_DMS.xlsx 的列顺序与 associationMatrix.xlsx 列顺序不一致")

        dis_rows = (
            pd.read_excel(disease_path, sheet_name=0, usecols=[0], header=0)
            .iloc[:, 0]
            .map(_norm_str)
            .dropna()
            .tolist()
        )
        if dis_rows and dis_rows != disease_order:
            raise ValueError("275GS_DMS.xlsx 的行顺序与 associationMatrix.xlsx 列顺序不一致")

        circ_header = pd.read_excel(circ_sim_path, sheet_name=0, nrows=0).columns.tolist()
        circ_header = [_norm_str(c) for c in circ_header]
        circ_header = [c for c in circ_header if c is not None]
        if len(circ_header) >= 2 and circ_header[1:] != circ_order:
            raise ValueError("circRNA 相似矩阵的列顺序与 associationMatrix.xlsx 行顺序不一致")

        circ_rows = (
            pd.read_excel(circ_sim_path, sheet_name=0, usecols=[0], header=0)
            .iloc[:, 0]
            .map(_norm_str)
            .dropna()
            .tolist()
        )
        if circ_rows and circ_rows != circ_order:
            raise ValueError("circRNA 相似矩阵的行顺序与 associationMatrix.xlsx 行顺序不一致")

    return NodeMappings(
        circRNA_name_to_id={name: i for i, name in enumerate(circ_order)},
        disease_name_to_id={name: i for i, name in enumerate(disease_order)},
    )


def load_association_pairs(
    data_dir: Path,
    assoc_pairs_file: str = "去重+名称标准化后的最终数据库.xlsx",
    circ_col: str = "RNA 名称",
    disease_col: str = "疾病名称",
) -> pd.DataFrame:
    path = data_dir / assoc_pairs_file
    df = pd.read_excel(path)
    if circ_col not in df.columns or disease_col not in df.columns:

        def _canon_col(c: str) -> str:
            return "".join(ch for ch in str(c).strip().lower() if ch not in {" ", "\t", "\n", "\r", "_"})

        cols = list(df.columns)
        canon_to_actual = {_canon_col(c): c for c in cols}

        circ_candidates = [
            circ_col,
            "circRNA Name",
            "circRNA",
            "circRNA名称",
            "RNA名称",
            "RNA 名称",
        ]
        dis_candidates = [
            disease_col,
            "Disease Name",
            "disease",
            "疾病名称",
            "Disease",
        ]

        def _pick(cands: list[str]) -> str | None:
            for cand in cands:
                if cand in cols:
                    return cand
            for cand in cands:
                key = _canon_col(cand)
                if key in canon_to_actual:
                    return canon_to_actual[key]
            return None

        circ_pick = _pick(circ_candidates)
        dis_pick = _pick(dis_candidates)

        if circ_pick is None or dis_pick is None:
            raise KeyError(
                f"关联对文件缺少所需列: {circ_col!r}, {disease_col!r}. 实际列: {cols}"
            )

        circ_col = circ_pick
        disease_col = dis_pick
    out = df[[circ_col, disease_col]].copy()
    out[circ_col] = out[circ_col].map(_norm_str)
    out[disease_col] = out[disease_col].map(_norm_str)
    out = out.dropna(subset=[circ_col, disease_col]).reset_index(drop=True)
    out = out.rename(columns={circ_col: "circRNA_name", disease_col: "disease_name"})
    return out


def build_edge_table(
    assoc_pairs: pd.DataFrame,
    mappings: NodeMappings,
    strict: bool = True,
) -> tuple[pd.DataFrame, dict[str, int]]:
    circ_map = mappings.circRNA_name_to_id
    dis_map = mappings.disease_name_to_id

    circ_ids = assoc_pairs["circRNA_name"].map(circ_map)
    dis_ids = assoc_pairs["disease_name"].map(dis_map)

    missing_circ = assoc_pairs.loc[circ_ids.isna(), "circRNA_name"].value_counts()
    missing_dis = assoc_pairs.loc[dis_ids.isna(), "disease_name"].value_counts()

    if strict and (len(missing_circ) > 0 or len(missing_dis) > 0):
        sample_circ = missing_circ.head(10).to_dict()
        sample_dis = missing_dis.head(10).to_dict()
        raise ValueError(
            "存在无法映射到节点ID的名称。\n"
            f"缺失 circRNA 名称(示例): {sample_circ}\n"
            f"缺失 Disease 名称(示例): {sample_dis}\n"
            "可检查节点特征表/矩阵是否包含这些名称，或在 build_edge_table(strict=False) 下跳过缺失对。"
        )

    kept = assoc_pairs.loc[circ_ids.notna() & dis_ids.notna(), ["circRNA_name", "disease_name"]].copy()
    kept["circRNA_ID"] = kept["circRNA_name"].map(circ_map).astype("int64")
    kept["Disease_ID"] = kept["disease_name"].map(dis_map).astype("int64")

    before = len(kept)
    kept = kept.drop_duplicates(subset=["circRNA_ID", "Disease_ID"], keep="first").copy()
    after = len(kept)

    kept = kept.sort_values(["circRNA_ID", "Disease_ID"], ascending=[True, True]).reset_index(drop=True)

    kept["R_start"] = (kept.index * 2).astype("int64")
    kept["R_end"] = (kept.index * 2 + 1).astype("int64")

    edges = kept[["circRNA_ID", "Disease_ID", "R_start", "R_end"]].copy()

    stats = {
        "unique_circRNA": len(mappings.circRNA_name_to_id),
        "unique_disease": len(mappings.disease_name_to_id),
        "edges": len(edges),
        "duplicates_removed": before - after,
        "pairs_total": len(assoc_pairs),
        "pairs_kept": len(kept),
        "pairs_dropped_missing": len(assoc_pairs) - len(kept),
        "missing_circRNA_unique": int(missing_circ.shape[0]),
        "missing_disease_unique": int(missing_dis.shape[0]),
    }

    return edges, stats


def write_outputs(data_dir: Path, edges: pd.DataFrame, stats: dict[str, int]) -> tuple[Path, Path]:
    csv_path = data_dir / "circRNA_Disease_edges.csv"
    stats_path = data_dir / "circRNA_Disease_edges_stats.txt"

    edges.to_csv(csv_path, index=False, encoding="utf-8")

    lines = [
        f"unique_circRNA\t{stats['unique_circRNA']}",
        f"unique_disease\t{stats['unique_disease']}",
        f"edges\t{stats['edges']}",
        f"duplicates_removed\t{stats['duplicates_removed']}",
        f"pairs_total\t{stats['pairs_total']}",
        f"pairs_kept\t{stats['pairs_kept']}",
        f"pairs_dropped_missing\t{stats['pairs_dropped_missing']}",
        f"missing_circRNA_unique\t{stats['missing_circRNA_unique']}",
        f"missing_disease_unique\t{stats['missing_disease_unique']}",
    ]
    stats_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return csv_path, stats_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data_new")
    parser.add_argument("--validate-consistency", action="store_true")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--no-strict", action="store_true")
    args = parser.parse_args()

    if args.strict and args.no_strict:
        raise SystemExit("Conflicting flags: both --strict and --no-strict were provided.")

    strict = True if (not args.strict and not args.no_strict) else bool(args.strict)

    project_dir = Path(__file__).resolve().parents[1]
    data_dir = project_dir / args.data_dir
    data_dir.mkdir(parents=True, exist_ok=True)

    mappings = build_node_mappings(data_dir, validate_consistency=args.validate_consistency)
    assoc_pairs = load_association_pairs(data_dir)
    edges, stats = build_edge_table(assoc_pairs, mappings, strict=strict)

    circ_nodes = pd.DataFrame(
        {"circRNA_ID": list(mappings.circRNA_name_to_id.values()), "circRNA_name": list(mappings.circRNA_name_to_id.keys())}
    )
    dis_nodes = pd.DataFrame(
        {"Disease_ID": list(mappings.disease_name_to_id.values()), "disease_name": list(mappings.disease_name_to_id.keys())}
    )
    circ_nodes.to_csv(data_dir / "circRNA_nodes.csv", index=False, encoding="utf-8")
    dis_nodes.to_csv(data_dir / "Disease_nodes.csv", index=False, encoding="utf-8")

    write_outputs(data_dir, edges, stats)


if __name__ == "__main__":
    main()
